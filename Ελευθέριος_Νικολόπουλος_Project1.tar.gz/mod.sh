#!/bin/bash


# Diabazoume to arxeio kai kanei sort apo ths lexeis poy exoyn thn megaluterh suxnothta mexri thn mikroterh

cat Adams.txt | tr -s '[:blank:]' '\n' | sort | uniq -c | sort -nr -k1,1 | awk '{print $1 "," $2}' > word_var.txt   


cat word_var.txt | cut -d',' -f1 >> count.txt  # edo to count.txt exei mono thn syxnothta 
cat word_var.txt | cut -d',' -f2 >> word.txt   #to word.txt exei mono ths lexeis


awk '{print length}' word.txt >> cost.txt                       #to cost.txt einai posa grammata exei h kathe lexh
paste -d ',' word.txt count.txt cost.txt > listofwords.txt      #to listofwords.txt emfanizei ths lexhs thn syxnothta kai posa grammata exei h kathe lexh
awk -F ',' '{print $2 * $3}' listofwords.txt > total_cost.txt   #to total_cost.txt einai to athristiko kostos 
paste -d ',' listofwords.txt total_cost.txt > output.txt        #to output.txt einai ola ayta mazi 




# metatrepei kathe lexei me ena monadiko ascii xarakthra otan teleiosoyn oi xarakthrew xana arxizei apo thn arxh alla me enan parapanv xarakthra 
awk -v FS='\n' 'BEGIN{
    OFS=""
    char_start = 33  # ASCII value for "!"
    char_end = 126   # ASCII value for "~"
    char_count = char_end - char_start + 1
}

{
    len = length($0)
    if (NR <= char_count) {
        code = sprintf("%c", char_start + NR - 1)
    } else if (NR <= char_count * char_count + char_count) {
        i = NR - char_count - 1
        row = int(i / char_count)
        col = i % char_count
        code = sprintf("%c%c", char_start + row, char_start + col)
    } else {
        i = NR - char_count - char_count * char_count - 1
        page = int(i / (char_count * char_count))
        row = int((i % (char_count * char_count)) / char_count)
        col = (i % (char_count * char_count)) % char_count
        code = sprintf("%c%c%c", char_start + page, char_start + row, char_start + col)
    }
    printf("%s %s\n", $0, code)
}' word.txt > alphabet.txt



#dhmioyrgo to kodikopoihmeno arxeio 

awk 'BEGIN{FS=OFS=" "} NR==FNR{a[$1]=$2;next} {for(i=1;i<=NF;i++){if($i in a){$i=a[$i]}}; print}' alphabet.txt Adams.txt > coded.txt    
 

#antistrefo ths steiles tou alphabet   

awk 'BEGIN{FS=OFS=" "} {print $2 "," $1}' alphabet.txt > alphabet_new.txt           
   

#dhmioyrgo to apokodikopoihmeno arxeio                                                   

awk 'BEGIN{FS=OFS=" "} NR==FNR{a[$1]=$2;next} {for(i=1;i<=NF;i++){if($i in a){$i=a[$i]}}; print}' alphabet_new.txt Adams.txt > uncoded.txt   


gzip -c Adams.txt | wc -c > Adams_compressed_size.txt   #kano gzip to arxiko keimeno 
gzip -c coded.txt | wc -c > coded_compressed_size.txt   #kano gzip to kodikopoihmeno keimeno 


# edv ypologizei ti pososto sumpieseis petyxeno prosthetei ta 2 gzip /ta 2arxeia *100  

ratio=$(echo "scale=2;($(cat Adams_compressed_size.txt) + $(cat coded_compressed_size.txt)) / ($(wc -c < Adams.txt) + $(wc -c < coded.txt)) * 100" | bc)
echo "Ποσοστό συμπίεσης είναι : $ratio%"  




#sigkrinei to arxiko keimeno me to apokodikopoihmeno an einai idia

cmp Adams.txt uncoded.txt && echo "Τo Adams.txt και το uncoded.txt είναι ίδια " || echo "Τo Adams.txt και το uncoded.txt δεν είναι ίδια " 



#diagrafh ta arxeia poy den xreiazontai

rm cost.txt count.txt word.txt listofwords.txt total_cost.txt word_var.txt Adams_compressed_size.txt coded_compressed_size.txt 









